# Sources
# example lab results were taken from a google images search
# and are available at the following links

#apex medical
https://www.apexlabinc.com/images/PATIENT_TEST.JPG

# canvas medical
https://canvas-medical.zendesk.com/hc/article_attachments/4419333522451/labreqgif1.gif

# salem health
https://www.salemhealth.org/images/default-source/common-ground-photos/patient-test-result.jpg?sfvrsn=1138aec4_0

# research gate
https://www.researchgate.net/figure/Sample-of-Laboratory-Result-from-DHF-Patient_fig1_318040246/download

# GNU health lab report
https://upload.wikimedia.org/wikipedia/commons/4/44/GNU_Health_lab_report_sample.png

# drug tests 
https://www.americanmedicalreviewofficer.com/medical-review-officer-drug-testing-results/

# not used
https://www.apklas.com/