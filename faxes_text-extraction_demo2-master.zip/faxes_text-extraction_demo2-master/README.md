# faxes_demo
A demonstration of how to extract data from faxed lab results

# Privacy note
All the data is fake! I found a bunch of fake examples online by googling "lab result faxes". No actual patient data is stored in the raw data folder. See the <a href="https://github.com/DOH-RPS1303/faxes_demo/blob/master/readme_files/fax_image_sources.R">`fax_image_sources.R`</a> file for links to where each fake data file came from.
